(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_user-management_page_71263d.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_user-management_page_71263d.js",
  "chunks": [
    "static/chunks/node_modules_f8f107._.js",
    "static/chunks/src_e096d4._.js"
  ],
  "source": "dynamic"
});
